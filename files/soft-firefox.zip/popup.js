document.getElementById("aboutBtn").addEventListener("click", () => {
  browser.tabs.create({ url: "https://careerhack.hitsecurity.ru/" });
});
